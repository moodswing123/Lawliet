import { withAuth } from "next-auth/middleware"
import { NextResponse } from "next/server"

export default withAuth(
  function middleware(req) {
    const token = req.nextauth.token
    const isAuth = !!token

    const authPaths = ["/auth/signin", "/auth/signup", "/auth/reset-password"]
    const isAuthPath = authPaths.some((path) =>
      req.nextUrl.pathname.startsWith(path)
    )

    if (!isAuth && !isAuthPath) {
      return NextResponse.redirect(new URL("/auth/signin", req.url))
    }

    if (isAuth && isAuthPath) {
      return NextResponse.redirect(new URL("/", req.url))
    }

    return NextResponse.next()
  },
  {
    callbacks: {
      authorized: ({ token }) => !!token,
    },
  }
)

export const config = {
  matcher: [
    "/",
    "/chat/:path*",
    "/settings/:path*",
    "/auth/signin",
    "/auth/signup",
    "/auth/reset-password",
  ],
}